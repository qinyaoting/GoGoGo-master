---
name: 需求、功能、建议 / Demands, functions, suggestions
about: If you have please use this template.demands, functions or suggestions, please
  use this template.
title: "[Feature] New function"
labels: feature
assignees: ''

---

<!-- ⚠️⚠️ 不要删除这些注释 ⚠️⚠️ -->
<!-- ⚠️⚠️ DO NOT Delete those comments! ⚠️⚠️ -->
<!-- 请先搜索有无同类需求，避免提交重复需求 -->
<!-- Please search existing demands to avoid creating duplicates. -->

### 描述 / Description



<!-- 请在上方详细地描述你的需求、功能、建议。 -->
<!-- Please describe your demands, functions, suggestions above. -->

### 必要性 / Necessity



<!-- 请在上方详细地描述该需求、功能、建议 的必要性。 -->
<!-- Please describe why you need the demands, functions, suggestions. -->

