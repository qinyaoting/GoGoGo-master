---
name: 疑问或帮助 / Question or Help
about: If you have any question or need help, please use this template.
title: "[Question] Help"
labels: question
assignees: ''

---

<!-- ⚠️⚠️ 不要删除这些注释 ⚠️⚠️ -->
<!-- ⚠️⚠️ DO NOT Delete those comments! ⚠️⚠️ -->
<!-- 请先搜索有无同类问题，避免报告重复问题 -->
<!-- Please search existing issues to avoid creating duplicates. -->

### 问题描述 / Problem Description



<!-- 请在上方详细地描述详细地描述问题。 -->
<!-- Please describe your problem in detail above. -->

### 版本信息 / Version Info

- 影梭版本 / GoGoGo Version : 
- 系统版本 / OS Version : 

<!-- 请在上方描述出问题的影梭版本及使用的系统版本。 -->
<!-- Please describe version of GoGoGo and used OS above. -->
